<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Halaman Login</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <style type="text/css">
 * {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  font-size: 16px;
  line-height: 1.6;
  color: #333;
  background-color: #f4f4f4;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}

.box {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100vh;
  overflow: hidden;
  z-index: 0; /* Tambahkan z-index untuk menjaga elemen di belakang konten */
}

.box img {
  min-width: 100%;
  min-height: 100%;
  object-fit: cover; /* Memastikan gambar mengisi kotak tanpa deformasi */
}

.login-box, .register-box {
  background-color: rgba(255, 255, 255, 0.9); /* Latar belakang kotak login dengan alpha untuk membuatnya transparan */
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
  padding: 20px;
  width: 300px;
  text-align: center;
  position: relative; /* Tambahkan posisi relatif */
  z-index: 1; /* Tambahkan z-index untuk menempatkan elemen di atas latar belakang */
}

.login-box h2 {
  color: #333;
}

.form-group {
  margin-bottom: 15px;
}

.form-control {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.form-control-feedback {
  position: absolute;
  top: 50%;
  right: 10px;
  transform: translateY(-50%);
}

.btn-login {
  display: inline-block;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 70%; /* Membuat tombol menjadi bulat */
  padding: 10px 20px;
  font-size: 18px;
  cursor: pointer;
  transition: background-color 0.3s ease;
  text-decoration: none;
}

.large-round-button {
  display: inline-block;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 10%; /* Membuat tombol menjadi bulat */
  padding: 15px 30px; /* Sesuaikan ukuran padding sesuai dengan keinginan Anda */
  font-size: 10px; /* Sesuaikan ukuran font sesuai dengan keinginan Anda */
  cursor: pointer;
  transition: background-color 0.3s ease;
  text-decoration: none; /* Menghapus dekorasi teks default (jika diperlukan) */
}

.btn-login:hover {
  background-color: #0056b3;
}

/* Optional: Style the 'Remember Me' checkbox */
.icheckbox_square-blue, .iradio_square-blue {
  display: inline-block;
  margin-right: 10px;
}

/* Optional: Adjust form layout on small screens */
@media (max-width: 768px) {
  .login-box {
    width: 90%;
  }

  .btn-login {
    width: 100%;
  }
}
  
  
  </style>
  </head>
  <body class="hold-transition login-page">
  
    <header class="wrapper head">
      <div class="box">
        <img src="Wallpaper4.jpg"></img>
      </div>
      <div class="content">
      <div class="login-box">
    <div class="login-logo">
      <H2>USER LOGIN </H2>
    </div>
    <div class="login-box-body">
      <form action="login.php" method="post">
        <div class="form-group has-feedback">
          <input type="text" class="form-control" name="txtusername" placeholder="User Name">
          <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
        </div>
        <div class="form-group has-feedback">
          <input type="password" class="form-control" name="txtpassword" placeholder="Password">
          <span class="glyphicon glyphicon-lock form-control-feedback"></span>
        </div>
        <div class="row">
          <!-- /.col -->
          <div class="col-xs-4">
            <button type="submit" name="btnlogin" class="large-round-button">LOGIN</button> <br><br>
          </div>
          <!-- /.col -->
        </div>
      </form>
  
  
    </div>
  </div>
      </div>
    </header>
  <script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>
  <script src="plugins/iCheck/icheck.min.js"></script>
  <script>
    $(function () {
      $('input').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        radioClass: 'iradio_square-blue',
        increaseArea: '20%' // optional
      });
    });
  </script>
  
  